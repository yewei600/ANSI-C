#include <stdio.h>

main()
{
	printf("On this system the value of EOF is %d.\n", EOF);
}
