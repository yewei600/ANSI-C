#include <stdio.h>

main()
{
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
	printf("%d", getchar() != EOF);
}
